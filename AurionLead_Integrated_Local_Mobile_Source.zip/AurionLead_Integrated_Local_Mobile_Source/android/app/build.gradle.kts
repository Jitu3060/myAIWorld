plugins { id("com.android.application"); id("org.jetbrains.kotlin.android") }
android {
    namespace = "com.aurionlead.integrated"
    compileSdk = 35
    defaultConfig { applicationId = "com.aurionlead.integrated"; minSdk = 26; targetSdk = 35; versionCode = 1; versionName = "0.2.0" }
}
dependencies { implementation("androidx.webkit:webkit:1.12.1") }
