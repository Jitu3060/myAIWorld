"use client"

import { useState } from "react"
import { ProductCard } from "@/components/product-card"
import { ProductFilters } from "@/components/product-filters"
import { Search } from "lucide-react"
import { Input } from "@/components/ui/input"

const SAMPLE_PRODUCTS = [
  {
    id: 1,
    name: "Handwoven Wall Hanging",
    nameOdia: "ହାତରେ ବୁଣା କାନ୍ଥ ଟାଙ୍ଗିବା",
    price: 850,
    category: "Home Decor",
    image: "/handwoven-wall-hanging-indian-textile-art.jpg",
  },
  {
    id: 2,
    name: "Traditional Odia Painting",
    nameOdia: "ପାରମ୍ପରିକ ଓଡ଼ିଆ ଚିତ୍ର",
    price: 1200,
    category: "Paintings",
    image: "/traditional-odia-pattachitra-painting-art.jpg",
  },
  {
    id: 3,
    name: "Silver Filigree Earrings",
    nameOdia: "ରୂପା ତାରକସି କାନ ଫୁଲ",
    price: 650,
    category: "Jewellery",
    image: "/silver-filigree-earrings-indian-jewelry.jpg",
  },
  {
    id: 4,
    name: "Clay Diya Set",
    nameOdia: "ମାଟି ଦୀପ ସେଟ୍",
    price: 320,
    category: "Home Decor",
    image: "/handmade-clay-diya-traditional-indian-lamps.jpg",
  },
  {
    id: 5,
    name: "Jute Table Runner",
    nameOdia: "ଜୁଟ ଟେବୁଲ ରନର୍",
    price: 450,
    category: "Home Decor",
    image: "/jute-table-runner-handmade-natural-fiber.jpg",
  },
  {
    id: 6,
    name: "Dokra Brass Figurine",
    nameOdia: "ଡକରା ପିତଳ ମୂର୍ତ୍ତି",
    price: 980,
    category: "Home Decor",
    image: "/dokra-brass-figurine-tribal-art-sculpture.jpg",
  },
  {
    id: 7,
    name: "Madhubani Canvas Art",
    nameOdia: "ମଧୁବନୀ କାନଭାସ୍ ଚିତ୍ର",
    price: 1500,
    category: "Paintings",
    image: "/madhubani-painting-canvas-folk-art.jpg",
  },
  {
    id: 8,
    name: "Beaded Necklace",
    nameOdia: "ବିଡ୍ ହାର",
    price: 580,
    category: "Jewellery",
    image: "/handmade-beaded-necklace-indian-ethnic-jewelry.jpg",
  },
  {
    id: 9,
    name: "Terracotta Vase",
    nameOdia: "ଟେରାକୋଟା ଫୁଲଦାନୀ",
    price: 720,
    category: "Home Decor",
    image: "/terracotta-vase-handmade-indian-pottery.jpg",
  },
]

export function ProductCatalog() {
  const [searchQuery, setSearchQuery] = useState("")
  const [selectedCategory, setSelectedCategory] = useState<string>("all")
  const [priceRange, setPriceRange] = useState<[number, number]>([0, 10000])

  const filteredProducts = SAMPLE_PRODUCTS.filter((product) => {
    const matchesSearch = product.name.toLowerCase().includes(searchQuery.toLowerCase())
    const matchesCategory = selectedCategory === "all" || product.category === selectedCategory
    const matchesPrice = product.price >= priceRange[0] && product.price <= priceRange[1]
    return matchesSearch && matchesCategory && matchesPrice
  })

  return (
    <section id="products" className="py-16 lg:py-24">
      <div className="container mx-auto px-4 lg:px-8">
        <div className="text-center mb-12">
          <h2 className="text-3xl lg:text-4xl font-serif font-bold text-foreground mb-4">Our Handmade Collection</h2>
          <p className="text-lg text-muted-foreground max-w-2xl mx-auto">
            Each piece is crafted with love and tradition by skilled artisans
          </p>
        </div>

        {/* Search Bar */}
        <div className="max-w-2xl mx-auto mb-8">
          <div className="relative">
            <Search className="absolute left-3 top-1/2 -translate-y-1/2 h-5 w-5 text-muted-foreground" />
            <Input
              type="search"
              placeholder="Search for products..."
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              className="pl-10 h-12"
            />
          </div>
        </div>

        <div className="grid lg:grid-cols-[280px_1fr] gap-8">
          {/* Filters */}
          <ProductFilters
            selectedCategory={selectedCategory}
            onCategoryChange={setSelectedCategory}
            priceRange={priceRange}
            onPriceRangeChange={setPriceRange}
          />

          {/* Product Grid */}
          <div>
            <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-6">
              {filteredProducts.map((product) => (
                <ProductCard key={product.id} product={product} />
              ))}
            </div>

            {filteredProducts.length === 0 && (
              <div className="text-center py-16">
                <p className="text-muted-foreground text-lg">No products found matching your criteria.</p>
              </div>
            )}
          </div>
        </div>
      </div>
    </section>
  )
}
