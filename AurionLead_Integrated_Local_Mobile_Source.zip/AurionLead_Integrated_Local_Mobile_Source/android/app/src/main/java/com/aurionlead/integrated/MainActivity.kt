package com.aurionlead.integrated

import android.annotation.SuppressLint
import android.app.Activity
import android.graphics.Color
import android.os.Bundle
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.webkit.CookieManager
import android.webkit.WebChromeClient
import android.webkit.WebResourceRequest
import android.webkit.WebView
import android.webkit.WebViewClient
import android.webkit.WebResourceResponse
import android.net.Uri
import android.widget.Button
import android.widget.LinearLayout
import android.widget.ProgressBar
import android.widget.TextView
import android.widget.Toast
import androidx.webkit.WebViewAssetLoader

class MainActivity : Activity() {
    companion object {
        private const val INTEGRO_URL = "http://115.124.101.220:9090/integro/"
        private const val LOCAL_AURION_URL = "https://appassets.androidplatform.net/index.html"
        private const val ASSET_HOST = "appassets.androidplatform.net"
    }
    private lateinit var webView: WebView
    private lateinit var status: TextView
    private lateinit var progress: ProgressBar
    private lateinit var title: TextView
    private lateinit var assetLoader: WebViewAssetLoader
    private var current = "integro"

    @SuppressLint("SetJavaScriptEnabled")
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        assetLoader = WebViewAssetLoader.Builder()
            .addPathHandler("/", LocalAssetPathHandler())
            .build()

        val root = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setBackgroundColor(Color.WHITE) }
        val bar = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL; setPadding(dp(8), dp(4), dp(8), dp(4)); setBackgroundColor(Color.rgb(16,42,67)) }
        title = TextView(this).apply { text = "IntegroRetail"; textSize = 16f; setTextColor(Color.WHITE); setPadding(dp(8), 0, dp(8), 0) }
        bar.addView(title, LinearLayout.LayoutParams(0, dp(44), 1f))
        val integ = Button(this).apply { text = "IntegroRetail"; isAllCaps = false }
        val aurion = Button(this).apply { text = "AurionLead"; isAllCaps = false }
        bar.addView(integ); bar.addView(aurion); root.addView(bar)
        progress = ProgressBar(this, null, android.R.attr.progressBarStyleHorizontal).apply { max = 100; visibility = View.GONE }
        root.addView(progress, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, dp(3)))
        status = TextView(this).apply { setTextColor(Color.DKGRAY); textSize = 12f; setPadding(dp(12), dp(6), dp(12), dp(6)); visibility = View.GONE }
        root.addView(status)
        webView = WebView(this).apply {
            settings.javaScriptEnabled = true
            settings.domStorageEnabled = true
            settings.loadsImagesAutomatically = true
            settings.javaScriptCanOpenWindowsAutomatically = false
            settings.setSupportMultipleWindows(false)
        }
        webView.webViewClient = object : WebViewClient() {
            override fun shouldInterceptRequest(view: WebView?, request: WebResourceRequest?) = request?.url?.let { assetLoader.shouldInterceptRequest(it) }
            override fun shouldOverrideUrlLoading(view: WebView?, request: WebResourceRequest?): Boolean {
                val uri = request?.url ?: return false
                // Keep remote IntegroRetail navigation inside the WebView. Never route external links to arbitrary native actions.
                if (uri.scheme == "https" && uri.host == ASSET_HOST) return false
                if (uri.scheme == "http" || uri.scheme == "https") return false
                Toast.makeText(this@MainActivity, "This link type is not supported in the demo.", Toast.LENGTH_SHORT).show()
                return true
            }
            override fun onPageStarted(view: WebView?, url: String?, favicon: android.graphics.Bitmap?) { status.visibility = View.GONE }
            override fun onReceivedError(view: WebView?, request: WebResourceRequest?, error: android.webkit.WebResourceError?) {
                if (request?.isForMainFrame == true) { status.text = "Page could not load. Check network access, then select the tab again to retry."; status.visibility = View.VISIBLE }
            }
        }
        webView.webChromeClient = object : WebChromeClient() {
            override fun onProgressChanged(view: WebView?, value: Int) { progress.progress = value; progress.visibility = if (value in 1..99) View.VISIBLE else View.GONE }
            override fun onReceivedTitle(view: WebView?, pageTitle: String?) { title.text = pageTitle?.takeIf { it.isNotBlank() } ?: if (current == "integro") "IntegroRetail" else "AurionLead" }
        }
        CookieManager.getInstance().setAcceptCookie(true)
        CookieManager.getInstance().setAcceptThirdPartyCookies(webView, true)
        root.addView(webView, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, 0, 1f))
        setContentView(root)
        integ.setOnClickListener { open("integro") }
        aurion.setOnClickListener { open("aurion") }
        open("integro")
    }

    private fun open(destination: String) {
        current = destination
        status.visibility = View.GONE
        title.text = if (destination == "integro") "IntegroRetail" else "AurionLead"
        webView.loadUrl(if (destination == "integro") INTEGRO_URL else LOCAL_AURION_URL)
    }

    @Deprecated("Deprecated in Java")
    override fun onBackPressed() {
        if (::webView.isInitialized && webView.canGoBack()) webView.goBack()
        else if (current == "aurion") open("integro") else super.onBackPressed()
    }

    // Serves bundled prototype files and maps extensionless TanStack routes to HTML with the correct MIME type.
    private inner class LocalAssetPathHandler : WebViewAssetLoader.PathHandler {
        override fun handle(path: String): android.webkit.WebResourceResponse? {
            val clean = path.trimStart('/')
            if (clean.contains("..") || clean.startsWith("\\")) return null
            val knownRoutes = setOf("", "today", "leads", "planner", "map", "cold-leads", "executive", "performance")
            val assetPath = if (clean.isBlank()) "index.html" else clean
            val mime = when {
                assetPath in knownRoutes -> "text/html"
                assetPath.endsWith(".html", ignoreCase = true) -> "text/html"
                assetPath.endsWith(".js", ignoreCase = true) || assetPath.endsWith(".mjs", ignoreCase = true) -> "text/javascript"
                assetPath.endsWith(".css", ignoreCase = true) -> "text/css"
                assetPath.endsWith(".svg", ignoreCase = true) -> "image/svg+xml"
                assetPath.endsWith(".png", ignoreCase = true) -> "image/png"
                assetPath.endsWith(".jpg", ignoreCase = true) || assetPath.endsWith(".jpeg", ignoreCase = true) -> "image/jpeg"
                assetPath.endsWith(".woff2", ignoreCase = true) -> "font/woff2"
                else -> "application/octet-stream"
            }
            return try {
                WebResourceResponse(mime, "UTF-8", assets.open(assetPath))
            } catch (_: Exception) {
                if (assetPath in knownRoutes && assetPath.isNotBlank()) {
                    try { WebResourceResponse("text/html", "UTF-8", assets.open("index.html")) } catch (_: Exception) { null }
                } else null
            }
        }
    }

    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()
}
