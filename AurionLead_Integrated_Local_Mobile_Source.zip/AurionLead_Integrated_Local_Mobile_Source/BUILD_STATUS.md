# Build status

The package is source-only. The existing APK was inspected as a ZIP and contains strings for the configured IntegroRetail URL, but the original source/signing key is not available. This project uses a new application ID and must be installed alongside the existing APK.

The bundled prototype route HTML files were generated from the provided built server output. Android WebView hydration and route navigation have not been verified on a device. No APK was built because Android SDK/build tools are not available in the authoring environment.
