"use client"

import Link from "next/link"
import Image from "next/image"
import { useLanguage } from "@/lib/language-store"

export function Footer() {
  const { language } = useLanguage()

  return (
    <footer className="bg-muted/30 border-t border-border mt-16">
      <div className="container mx-auto px-4 lg:px-8 py-12 lg:py-16">
        <div className="grid grid-cols-1 md:grid-cols-4 gap-8 mb-8">
          {/* Brand */}
          <div className="md:col-span-2">
            <div className="flex items-center gap-3 mb-4">
              <div className="relative w-24 h-24">
                <Image src="/images/image.png" alt="Gruhini Logo" fill className="object-contain" />
              </div>
            </div>
            {language === "od" ? (
              <>
                <p className="text-muted-foreground mb-2 leading-relaxed font-serif">ଆମ ଘର ପାଇଁ, ଆମ ଲୋକଙ୍କ ହାତରେ ତିଆରି</p>
                <p className="text-muted-foreground leading-relaxed text-sm">Handmade with love for our homes</p>
              </>
            ) : (
              <>
                <p className="text-muted-foreground mb-2 leading-relaxed">Handmade with love for our homes</p>
                <p className="text-muted-foreground leading-relaxed text-sm font-serif">ଆମ ଘର ପାଇଁ, ଆମ ଲୋକଙ୍କ ହାତରେ ତିଆରି</p>
              </>
            )}
          </div>

          {/* Quick Links */}
          <div>
            <h4 className="font-semibold mb-4">{language === "od" ? "ଶୀଘ୍ର ଲିଙ୍କ୍" : "Quick Links"}</h4>
            <ul className="space-y-2">
              <li>
                <Link href="/" className="text-muted-foreground hover:text-foreground transition-colors">
                  {language === "od" ? "ମୂଳ" : "Home"}
                </Link>
              </li>
              <li>
                <Link href="#products" className="text-muted-foreground hover:text-foreground transition-colors">
                  {language === "od" ? "ଉତ୍ପାଦ" : "Products"}
                </Link>
              </li>
              <li>
                <Link href="#about" className="text-muted-foreground hover:text-foreground transition-colors">
                  {language === "od" ? "ଆମ ବିଷୟରେ" : "About Us"}
                </Link>
              </li>
              <li>
                <Link href="#contact" className="text-muted-foreground hover:text-foreground transition-colors">
                  {language === "od" ? "ଯୋଗାଯୋଗ" : "Contact"}
                </Link>
              </li>
            </ul>
          </div>

          {/* Policies */}
          <div>
            <h4 className="font-semibold mb-4">{language === "od" ? "ନୀତି" : "Policies"}</h4>
            <ul className="space-y-2">
              <li>
                <Link href="#" className="text-muted-foreground hover:text-foreground transition-colors">
                  {language === "od" ? "ଗୋପନୀୟତା ନୀତି" : "Privacy Policy"}
                </Link>
              </li>
              <li>
                <Link href="#" className="text-muted-foreground hover:text-foreground transition-colors">
                  {language === "od" ? "ସିପଂ ନୀତି" : "Shipping Policy"}
                </Link>
              </li>
              <li>
                <Link href="#" className="text-muted-foreground hover:text-foreground transition-colors">
                  {language === "od" ? "ରିଟର୍ନ ନୀତି" : "Return Policy"}
                </Link>
              </li>
              <li>
                <Link href="#" className="text-muted-foreground hover:text-foreground transition-colors">
                  {language === "od" ? "ସେବା ସର୍ତ୍ତାବଳୀ" : "Terms of Service"}
                </Link>
              </li>
            </ul>
          </div>
        </div>

        {/* Bottom Bar */}
        <div className="border-t border-border pt-8 text-center text-sm text-muted-foreground">
          {language === "od" ? (
            <p>© 2025 ଗୃହିଣୀ (Gruhini). ସମସ୍ତ ଅଧିକାର ସଂରକ୍ଷିତ | ଭାରତୀୟ ଘର ପାଇଁ ପ୍ରେମରେ ନିର୍ମିତ</p>
          ) : (
            <p>© 2025 Gruhini (ଗୃହିଣୀ). All rights reserved | Made with love for Indian homes</p>
          )}
        </div>
      </div>
    </footer>
  )
}
