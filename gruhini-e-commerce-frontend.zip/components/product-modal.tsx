"use client"

import { Dialog, DialogContent, DialogHeader, DialogTitle } from "@/components/ui/dialog"
import { Button } from "@/components/ui/button"
import { ShoppingCart, Package } from "lucide-react"
import { useCart } from "@/hooks/use-cart"

interface Product {
  id: number
  name: string
  nameOdia: string
  price: number
  category: string
  image: string
}

interface ProductModalProps {
  product: Product
  open: boolean
  onOpenChange: (open: boolean) => void
}

export function ProductModal({ product, open, onOpenChange }: ProductModalProps) {
  const { addItem } = useCart()

  const handleAddToCart = () => {
    addItem(product)
    onOpenChange(false)
  }

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent className="max-w-3xl max-h-[90vh] overflow-y-auto">
        <DialogHeader>
          <DialogTitle className="text-2xl font-serif">{product.name}</DialogTitle>
        </DialogHeader>

        <div className="grid md:grid-cols-2 gap-6">
          {/* Image */}
          <div className="aspect-square overflow-hidden rounded-lg bg-muted">
            <img src={product.image || "/placeholder.svg"} alt={product.name} className="w-full h-full object-cover" />
          </div>

          {/* Details */}
          <div className="space-y-6">
            <div>
              <span className="text-sm font-medium text-secondary uppercase tracking-wide">{product.category}</span>
              <p className="text-lg text-muted-foreground mt-1">{product.nameOdia}</p>
            </div>

            <div>
              <span className="text-3xl font-bold text-foreground">₹{product.price}</span>
            </div>

            <div>
              <h4 className="font-semibold mb-2">Description</h4>
              <p className="text-muted-foreground leading-relaxed">
                This beautiful {product.name.toLowerCase()} is handcrafted by skilled local artisans using traditional
                techniques passed down through generations. Each piece is unique and carries the authentic touch of
                Indian craftsmanship.
              </p>
            </div>

            <div className="bg-muted p-4 rounded-lg">
              <div className="flex items-start gap-2">
                <Package className="h-5 w-5 text-muted-foreground mt-0.5" />
                <div>
                  <p className="text-sm font-medium">Delivery Information</p>
                  <p className="text-sm text-muted-foreground mt-1">Estimated delivery: 5-7 business days</p>
                </div>
              </div>
            </div>

            <div className="flex gap-3">
              <Button size="lg" className="flex-1" onClick={handleAddToCart}>
                <ShoppingCart className="h-5 w-5 mr-2" />
                Add to Cart
              </Button>
              <Button size="lg" variant="secondary" className="flex-1">
                Buy Now
              </Button>
            </div>
          </div>
        </div>
      </DialogContent>
    </Dialog>
  )
}
