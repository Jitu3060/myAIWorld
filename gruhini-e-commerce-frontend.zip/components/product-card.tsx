"use client"

import { Card, CardContent } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { ShoppingCart, Eye } from "lucide-react"
import { useCart } from "@/hooks/use-cart"
import { useState } from "react"
import { ProductModal } from "@/components/product-modal"

interface Product {
  id: number
  name: string
  nameOdia: string
  price: number
  category: string
  image: string
}

interface ProductCardProps {
  product: Product
}

export function ProductCard({ product }: ProductCardProps) {
  const { addItem } = useCart()
  const [showModal, setShowModal] = useState(false)

  return (
    <>
      <Card className="group hover:shadow-lg transition-shadow overflow-hidden">
        <div className="aspect-square overflow-hidden bg-muted">
          <img
            src={product.image || "/placeholder.svg"}
            alt={product.name}
            className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-300"
          />
        </div>
        <CardContent className="p-4">
          <div className="mb-2">
            <span className="text-xs font-medium text-secondary uppercase tracking-wide">{product.category}</span>
          </div>
          <h3 className="font-semibold text-foreground mb-1 line-clamp-1">{product.name}</h3>
          <p className="text-sm text-muted-foreground mb-3 line-clamp-1">{product.nameOdia}</p>
          <div className="flex items-center justify-between mb-4">
            <span className="text-xl font-bold text-foreground">₹{product.price}</span>
          </div>
          <div className="flex gap-2">
            <Button variant="outline" size="sm" className="flex-1 bg-transparent" onClick={() => setShowModal(true)}>
              <Eye className="h-4 w-4 mr-1" />
              View
            </Button>
            <Button size="sm" className="flex-1" onClick={() => addItem(product)}>
              <ShoppingCart className="h-4 w-4 mr-1" />
              Add
            </Button>
          </div>
        </CardContent>
      </Card>

      <ProductModal product={product} open={showModal} onOpenChange={setShowModal} />
    </>
  )
}
