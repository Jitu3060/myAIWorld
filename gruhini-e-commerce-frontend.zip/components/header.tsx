"use client"

import { ShoppingCart, User, Menu } from "lucide-react"
import { Button } from "@/components/ui/button"
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuSeparator,
  DropdownMenuTrigger,
} from "@/components/ui/dropdown-menu"
import { useCart } from "@/hooks/use-cart"
import { useState } from "react"
import Link from "next/link"
import { useLanguage } from "@/lib/language-store"
import Image from "next/image"

export function Header() {
  const { items } = useCart()
  const { language, setLanguage } = useLanguage()
  const [userType] = useState<"guest" | "customer" | "admin">("guest")

  const itemCount = items.reduce((acc, item) => acc + item.quantity, 0)

  return (
    <header className="sticky top-0 z-50 bg-card border-b border-border shadow-sm">
      <div className="container mx-auto px-4 lg:px-8">
        <div className="flex items-center justify-between h-20 lg:h-28">
          {/* Logo */}
          <Link href="/" className="flex items-center gap-3">
            <div className="relative w-32 h-24 lg:w-48 lg:h-32">
              <Image src="/images/image.png" alt="Gruhini Logo" fill className="object-contain" priority />
            </div>
          </Link>

          {/* Desktop Navigation */}
          <nav className="hidden lg:flex items-center gap-8">
            <Link href="/" className="text-sm font-medium text-foreground hover:text-primary transition-colors">
              {language === "od" ? "ମୂଳ" : "Home"}
            </Link>
            <Link href="#products" className="text-sm font-medium text-foreground hover:text-primary transition-colors">
              {language === "od" ? "ଉତ୍ପାଦ" : "Products"}
            </Link>
            <Link href="#about" className="text-sm font-medium text-foreground hover:text-primary transition-colors">
              {language === "od" ? "ବିଷୟରେ" : "About"}
            </Link>
            <Link href="#contact" className="text-sm font-medium text-foreground hover:text-primary transition-colors">
              {language === "od" ? "ଯୋଗାଯୋଗ" : "Contact"}
            </Link>
          </nav>

          {/* Right Side Actions */}
          <div className="flex items-center gap-2 lg:gap-4">
            {/* Language Switcher */}
            <Button
              variant="ghost"
              size="sm"
              onClick={() => setLanguage(language === "en" ? "od" : "en")}
              className="hidden lg:flex"
            >
              {language === "od" ? "ଓଡ଼ିଆ" : "EN"}
            </Button>

            {/* Cart */}
            <Button variant="ghost" size="icon" className="relative">
              <ShoppingCart className="h-5 w-5" />
              {itemCount > 0 && (
                <span className="absolute -top-1 -right-1 bg-primary text-primary-foreground text-xs rounded-full h-5 w-5 flex items-center justify-center font-medium">
                  {itemCount}
                </span>
              )}
            </Button>

            {/* User Menu */}
            <DropdownMenu>
              <DropdownMenuTrigger asChild>
                <Button variant="ghost" size="icon">
                  <User className="h-5 w-5" />
                </Button>
              </DropdownMenuTrigger>
              <DropdownMenuContent align="end" className="w-48">
                {userType === "guest" && (
                  <>
                    <DropdownMenuItem>{language === "od" ? "ଲଗଇନ୍" : "Login"}</DropdownMenuItem>
                    <DropdownMenuItem>{language === "od" ? "ରେଜିଷ୍ଟର" : "Register"}</DropdownMenuItem>
                  </>
                )}
                {userType === "customer" && (
                  <>
                    <DropdownMenuItem>{language === "od" ? "ମୋ ଅର୍ଡର" : "My Orders"}</DropdownMenuItem>
                    <DropdownMenuSeparator />
                    <DropdownMenuItem>{language === "od" ? "ଲଗଆଉଟ୍" : "Logout"}</DropdownMenuItem>
                  </>
                )}
                {userType === "admin" && (
                  <>
                    <DropdownMenuItem>{language === "od" ? "ଆଡମିନ୍ ପ୍ୟାନେଲ" : "Admin Panel"}</DropdownMenuItem>
                    <DropdownMenuSeparator />
                    <DropdownMenuItem>{language === "od" ? "ଲଗଆଉଟ୍" : "Logout"}</DropdownMenuItem>
                  </>
                )}
              </DropdownMenuContent>
            </DropdownMenu>

            {/* Mobile Menu */}
            <Button variant="ghost" size="icon" className="lg:hidden">
              <Menu className="h-5 w-5" />
            </Button>
          </div>
        </div>
      </div>
    </header>
  )
}
