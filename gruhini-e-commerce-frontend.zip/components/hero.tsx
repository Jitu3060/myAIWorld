import { Button } from "@/components/ui/button"
import { ArrowRight } from "lucide-react"

export function Hero() {
  return (
    <section className="relative bg-gradient-to-b from-muted/30 to-background">
      <div className="container mx-auto px-4 lg:px-8 py-16 lg:py-24">
        <div className="max-w-4xl mx-auto text-center">
          <h1 className="text-4xl lg:text-6xl font-serif font-bold text-foreground mb-4 lg:mb-6 text-balance">
            Beautiful handmade items for everyday homes
          </h1>
          <p className="text-xl lg:text-2xl text-muted-foreground mb-6 lg:mb-8 font-serif">
            ଆମ ଘର ପାଇଁ, ଆମ ଲୋକଙ୍କ ହାତରେ ତିଆରି
          </p>
          <p className="text-base lg:text-lg text-muted-foreground mb-8 lg:mb-10 max-w-2xl mx-auto leading-relaxed">
            Discover authentic handcrafted home decor, paintings, and jewellery made by talented local artisans. Every
            piece tells a story of tradition and craftsmanship.
          </p>
          <div className="flex flex-col sm:flex-row gap-4 justify-center items-center">
            <Button size="lg" className="bg-primary hover:bg-primary/90 text-primary-foreground px-8">
              Shop Now
              <ArrowRight className="ml-2 h-5 w-5" />
            </Button>
            <Button size="lg" variant="outline" className="px-8 bg-transparent">
              Learn Our Story
            </Button>
          </div>
        </div>
      </div>

      {/* Decorative Elements */}
      <div className="absolute top-20 left-10 w-32 h-32 bg-accent/20 rounded-full blur-3xl" />
      <div className="absolute bottom-20 right-10 w-40 h-40 bg-secondary/10 rounded-full blur-3xl" />
    </section>
  )
}
