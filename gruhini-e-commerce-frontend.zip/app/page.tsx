import { Header } from "@/components/header"
import { Hero } from "@/components/hero"
import { ProductCatalog } from "@/components/product-catalog"
import { ValueProposition } from "@/components/value-proposition"
import { Footer } from "@/components/footer"
import { CartDrawer } from "@/components/cart-drawer"

export default function Home() {
  return (
    <>
      <Header />
      <main>
        <Hero />
        <ProductCatalog />
        <ValueProposition />
      </main>
      <Footer />
      <CartDrawer />
    </>
  )
}
