"use client"

import { Dialog, DialogContent, DialogHeader, DialogTitle } from "@/components/ui/dialog"
import { Button } from "@/components/ui/button"
import { Label } from "@/components/ui/label"
import { RadioGroup, RadioGroupItem } from "@/components/ui/radio-group"
import { useState } from "react"

interface CheckoutModalProps {
  open: boolean
  onOpenChange: (open: boolean) => void
  total: number
}

export function CheckoutModal({ open, onOpenChange, total }: CheckoutModalProps) {
  const [paymentMethod, setPaymentMethod] = useState("upi")

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent className="max-w-md">
        <DialogHeader>
          <DialogTitle className="text-2xl font-serif">Checkout</DialogTitle>
        </DialogHeader>

        <div className="space-y-6">
          <div className="bg-muted p-4 rounded-lg">
            <div className="flex items-center justify-between">
              <span className="text-muted-foreground">Total Amount:</span>
              <span className="text-2xl font-bold">₹{total}</span>
            </div>
          </div>

          <div>
            <h3 className="font-semibold mb-4">Select Payment Method</h3>
            <RadioGroup value={paymentMethod} onValueChange={setPaymentMethod}>
              <div className="space-y-3">
                {/* UPI Apps */}
                <div className="border rounded-lg p-4">
                  <div className="flex items-center space-x-2">
                    <RadioGroupItem value="upi" id="upi" />
                    <Label htmlFor="upi" className="flex-1 cursor-pointer font-medium">
                      UPI Apps
                    </Label>
                  </div>
                  {paymentMethod === "upi" && (
                    <div className="mt-3 pl-6 space-y-2">
                      <Button variant="outline" className="w-full justify-start bg-transparent" size="sm">
                        <img src="/gpay.jpg" alt="GPay" className="h-5 w-5 mr-2" />
                        Google Pay
                      </Button>
                      <Button variant="outline" className="w-full justify-start bg-transparent" size="sm">
                        <img src="/phonepe.jpg" alt="PhonePe" className="h-5 w-5 mr-2" />
                        PhonePe
                      </Button>
                      <Button variant="outline" className="w-full justify-start bg-transparent" size="sm">
                        <img src="/digital-wallet-app.png" alt="Paytm" className="h-5 w-5 mr-2" />
                        Paytm
                      </Button>
                    </div>
                  )}
                </div>

                {/* UPI QR Code */}
                <div className="border rounded-lg p-4">
                  <div className="flex items-center space-x-2">
                    <RadioGroupItem value="qr" id="qr" />
                    <Label htmlFor="qr" className="flex-1 cursor-pointer font-medium">
                      UPI QR Code
                    </Label>
                  </div>
                  {paymentMethod === "qr" && (
                    <div className="mt-3 pl-6">
                      <div className="bg-muted aspect-square rounded-lg flex items-center justify-center">
                        <img src="/upi-qr-code.jpg" alt="UPI QR Code" className="w-48 h-48" />
                      </div>
                      <p className="text-sm text-muted-foreground text-center mt-2">Scan with any UPI app</p>
                    </div>
                  )}
                </div>

                {/* Cash on Delivery */}
                <div className="border rounded-lg p-4">
                  <div className="flex items-center space-x-2">
                    <RadioGroupItem value="cod" id="cod" />
                    <Label htmlFor="cod" className="flex-1 cursor-pointer font-medium">
                      Cash on Delivery
                    </Label>
                  </div>
                  {paymentMethod === "cod" && (
                    <p className="text-sm text-muted-foreground mt-2 pl-6">
                      Pay with cash when your order is delivered
                    </p>
                  )}
                </div>
              </div>
            </RadioGroup>
          </div>

          <Button size="lg" className="w-full">
            Place Order
          </Button>

          <p className="text-xs text-center text-muted-foreground">
            This is a demo checkout. No actual payment will be processed.
          </p>
        </div>
      </DialogContent>
    </Dialog>
  )
}
