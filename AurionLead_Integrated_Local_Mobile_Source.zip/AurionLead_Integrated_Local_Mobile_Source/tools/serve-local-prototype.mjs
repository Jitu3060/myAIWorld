import { createServer } from 'node:http';
import { readFile } from 'node:fs/promises';
import path from 'node:path';
const root = path.resolve('android/app/src/main/assets');
const routes = new Set(['index.html','today','leads','planner','map','cold-leads','executive','performance']);
const mime = (p) => p.endsWith('.js') ? 'text/javascript' : p.endsWith('.css') ? 'text/css' : p.endsWith('.svg') ? 'image/svg+xml' : p.endsWith('.html') || !path.extname(p) ? 'text/html; charset=utf-8' : 'application/octet-stream';
createServer(async (req,res)=>{ try {
 let pathname = decodeURIComponent(new URL(req.url,'http://localhost').pathname).replace(/^\/+/, '') || 'index.html';
 let file = path.resolve(root, pathname);
 if (!file.startsWith(root)) throw new Error('bad path');
 try { const b=await readFile(file); res.writeHead(200,{'content-type':mime(file)}); res.end(b); }
 catch { const route=pathname.split('/')[0]; const fallback=routes.has(route)?route:'index.html'; const b=await readFile(path.join(root,fallback)); res.writeHead(200,{'content-type':'text/html; charset=utf-8'}); res.end(b); }
 } catch(e) {res.writeHead(404);res.end('Not found');}}).listen(4173,'127.0.0.1',()=>console.log('Local prototype assets at http://127.0.0.1:4173/'));
