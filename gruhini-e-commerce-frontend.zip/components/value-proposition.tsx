"use client"

import { useLanguage } from "@/lib/language-store"
import { Sparkles, Users, Leaf } from "lucide-react"

export function ValueProposition() {
  const { language } = useLanguage()

  const values = [
    {
      icon: Sparkles,
      titleEn: "Authentic & Artisanal",
      titleOd: "ପ୍ରାମାଣିକ ଓ କାରିଗରୀ",
      descriptionEn:
        "Every piece is handcrafted by skilled artisans using traditional techniques passed down through generations.",
      descriptionOd: "ପ୍ରତ୍ୟେକ ଖଣ୍ଡ ପାରମ୍ପରିକ କୌଶଳ ବ୍ୟବହାର କରି ଦକ୍ଷ କାରିଗରଙ୍କ ଦ୍ୱାରା ହସ୍ତଶିଳ୍ପ ତିଆରି।",
    },
    {
      icon: Users,
      titleEn: "Supporting Communities",
      titleOd: "ସମୁଦାୟକୁ ସମର୍ଥନ",
      descriptionEn: "When you shop with Gruhini, you directly support local women entrepreneurs and small creators.",
      descriptionOd: "ଯେତେବେଳେ ଆପଣ ଗୃହିଣୀରେ କିଣନ୍ତି, ଆପଣ ସିଧାସଳଖ ସ୍ଥାନୀୟ ମହିଳା ଉଦ୍ୟୋଗୀ ଏବଂ ଛୋଟ ସୃଜନକାରୀଙ୍କୁ ସମର୍ଥନ କରନ୍ତି।",
    },
    {
      icon: Leaf,
      titleEn: "Eco-Friendly & Sustainable",
      titleOd: "ପରିବେଶ ବନ୍ଧୁ ଓ ସ୍ଥାୟୀ",
      descriptionEn: "Made from natural, sustainable materials with zero waste practices. Good for you and the planet.",
      descriptionOd: "ପ୍ରାକୃତିକ, ସ୍ଥାୟୀ ସାମଗ୍ରୀରୁ ଶୂନ୍ୟ ବର୍ଜ୍ୟ ଅଭ୍ୟାସ ସହିତ ନିର୍ମିତ। ଆପଣଙ୍କ ଏବଂ ଗ୍ରହ ପାଇଁ ଭଲ।",
    },
  ]

  return (
    <section className="py-16 lg:py-20 bg-gradient-to-b from-background to-muted/30">
      <div className="container mx-auto px-4 lg:px-8">
        {/* Value Cards */}
        <div className="grid grid-cols-1 md:grid-cols-3 gap-6 lg:gap-8 mb-16">
          {values.map((value, index) => {
            const Icon = value.icon
            return (
              <div
                key={index}
                className="bg-card rounded-lg p-8 shadow-sm border border-border hover:shadow-md transition-shadow"
              >
                <Icon className="h-8 w-8 text-primary mb-4" />
                <h3 className="text-xl font-serif font-semibold text-primary mb-3">
                  {language === "od" ? value.titleOd : value.titleEn}
                </h3>
                <p className="text-muted-foreground leading-relaxed">
                  {language === "od" ? value.descriptionOd : value.descriptionEn}
                </p>
              </div>
            )
          })}
        </div>

        {/* CTA Section */}
        <div className="bg-primary rounded-2xl p-12 lg:p-16 text-center">
          <h2 className="text-3xl lg:text-4xl font-serif font-bold text-primary-foreground mb-4">
            {language === "od" ? "ସ୍ଥାନୀୟ କଳାକୁ ସମର୍ଥନ କରିବାକୁ ପ୍ରସ୍ତୁତ?" : "Ready to Support Local Art?"}
          </h2>
          <p className="text-primary-foreground/90 text-lg mb-8 max-w-2xl mx-auto">
            {language === "od"
              ? "ହଜାରେ ପରିବାରରେ ଯୋଗଦାନ କରନ୍ତୁ ଯେଉଁମାନେ କାରିଗରଙ୍କୁ ସମର୍ଥନ କରନ୍ତି ଏବଂ ସେମାନଙ୍କ ଘରେ ହସ୍ତଶିଳ୍ପ ସୌନ୍ଦର୍ଯ୍ୟ ଆଣନ୍ତି।"
              : "Join thousands of families supporting artisans and bringing handmade beauty into their homes."}
          </p>
          <button className="bg-card text-primary px-8 py-4 rounded-lg font-semibold text-lg hover:bg-card/90 transition-colors inline-flex items-center gap-2">
            {language === "od" ? "ହସ୍ତଶିଳ୍ପ କିଣନ୍ତୁ" : "Shop Handmade"}
            <svg className="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24">
              <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M9 5l7 7-7 7" />
            </svg>
          </button>
        </div>
      </div>
    </section>
  )
}
