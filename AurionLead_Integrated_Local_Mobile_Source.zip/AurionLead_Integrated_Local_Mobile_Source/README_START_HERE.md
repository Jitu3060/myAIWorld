# AurionLead Integrated Local Mobile Source (UAT candidate)

## What this package changes
- Creates a **new Android application source project** with two in-app destinations: the existing IntegroRetail web URL and a local bundled copy of the AurionLead prototype's generated browser assets.
- Does not change or deploy anything to `115.124.101.220:9090`.
- Keeps the supplied existing APK untouched.
- Bundles the prototype browser assets into Android `assets/`; no separate Vite dev server is needed for the bundled screens.

## Important limitations (please read)
- This is **source**, not an installable APK. No Android SDK/build tools are available in the current build environment, so an APK has not been compiled or device-tested.
- The source APK uses a hosted IntegroRetail URL. Its original signing key/source is not available here, so it cannot safely be modified in-place. This project has a different application ID (`com.aurionlead.integrated`) and will install as a separate test app.
- The prototype's supplied built output is a TanStack Start SSR build. The packaged route HTML files are generated server entry responses with client JS bundles. They were generated from the supplied `.output/server` and `.output/public/assets`; verify hydration on the target WebView before accepting this package. This is not yet evidence that all prototype routes work in Android WebView.
- The prototype still contains demo/mock data and is not connected to IntegroRetail's real lead database. The remote IntegroRetail destination remains the existing server URL; no data bridge/auth sharing is implemented in this increment.
- The original APK URL remains remote; only the prototype UI is bundled locally. Map tiles or third-party services, if referenced by screens, may still require network access.
- HTTP is enabled solely because the existing UAT URL uses HTTP. Do not use real customer data. Production requires HTTPS.

## Optional no-local-install build path (only if organization permits)
A GitHub Actions workflow is included at `.github/workflows/android-debug-apk.yml`. If your organization permits this code to be stored in a private GitHub repository and permits GitHub-hosted runners, push this project to a **private** repository, open Actions, choose **Build AurionLead Android debug APK**, and select **Run workflow**. Download the `aurionlead-mobile-debug-apk` artifact from the completed run. Do not upload company source to a third-party service unless company policy explicitly allows it. The workflow has not been run or verified.

## Build requirements
- JDK 17 or newer, Android SDK platform 35/build tools, Gradle/Android Gradle Plugin dependencies.
- If your organization prohibits local installations, use an organization-approved Android build runner. Do not upload company source to an unapproved public build service.

## Build using an approved Android builder
1. Open the `android` folder in VS Code or your approved build environment.
2. Set up JDK 17+ and Android SDK 35 using the organization's approved tool distribution.
3. Ensure Gradle 8.9+ is available. This project uses Android Gradle Plugin 8.7.3.
4. From the `android` folder run `gradle :app:assembleDebug` (or use the organization's CI job).
5. Expected APK: `android/app/build/outputs/apk/debug/app-debug.apk`.
6. Install as a separate app; do not uninstall the existing working APK.

## What to test on Android
1. Launch the new app; default destination should be IntegroRetail.
2. Confirm the existing hosted login loads inside the app.
3. Test existing approved UAT flows: Enquiry/Visit, create/save test application, Arya processing with approved test docs, Lead handover.
4. Tap AurionLead. Confirm local bundled prototype renders and the prototype login/navigation appears.
5. Exercise: My Day (`/`), Today's Route (`/today`), My Leads (`/leads`), Visit Planner (`/planner`), Geo Map (`/map`), Nearby Cold Leads (`/cold-leads`), Executive (`/executive`) and Performance (`/performance`).
6. Switch back to IntegroRetail and return to AurionLead. Confirm no external browser opens.
7. Turn network off: bundled prototype should still load its local shell/assets; IntegroRetail should show a network failure. Restore network.
8. Compare the same existing workflows in the old APK. Any regression blocks acceptance.

## Build/test status
- Inspected the provided APK archive and found URL strings for the IntegroRetail endpoint(s); the supplied APK contains no readily visible `assets/www` web bundle in its ZIP listing.
- Extracted the supplied prototype's generated `.output/server` and `.output/public/assets`, and generated HTML route entry responses for the listed prototype routes.
- No Android Gradle build, APK installation, WebView hydration test, live IntegroRetail regression test, or GPS/geofencing integration test was executed. These remain explicit validation blockers.
